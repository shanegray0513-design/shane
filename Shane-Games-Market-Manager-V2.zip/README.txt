SHANE GAMES — MARKET MANAGER V2

This is an original browser-based supermarket management game inspired by the genre.

OPEN:
1. Extract the ZIP.
2. Open index.html with Chrome or Edge.

FEATURES:
- Walk around with WASD/arrow keys.
- Customers move around and buy stock.
- Multiple products and inventory.
- Supplier ordering.
- Revenue, expenses, profit and business logs.
- Store upgrades.
- Day/time cycle.
- Automatic saves every 15 seconds.
- Manual save/load.
- Browser localStorage persistence.

NOTE:
It is not an exact copy of the commercial PC game Supermarket Simulator and does not use its copyrighted assets or code.
