const SAVE_KEY="shaneMarketManagerV2";
const PRODUCTS=[
{id:"bread",name:"Bread",icon:"🍞",cost:2.2,price:4.49,stock:12},
{id:"milk",name:"Milk",icon:"🥛",cost:2.8,price:5.49,stock:12},
{id:"soda",name:"Soda",icon:"🥤",cost:1.3,price:2.99,stock:12},
{id:"cereal",name:"Cereal",icon:"🥣",cost:3.1,price:6.49,stock:12},
{id:"chips",name:"Chips",icon:"🥔",cost:1.7,price:3.99,stock:12},
{id:"candy",name:"Candy",icon:"🍬",cost:.7,price:1.99,stock:12}
];
let game={money:1000,day:1,minute:480,stock:{bread:8,milk:8,soda:8,cereal:8,chips:8,candy:8},sold:0,revenue:0,expenses:0,customers:0,upgrade:{shelves:0,checkout:0,store:0},log:["Business opened."]};
let player={x:50,y:68,speed:0.7};
let keys={};let customers=[];let activeTab="store";

function money(n){return Number(n).toFixed(2)}
function product(id){return PRODUCTS.find(p=>p.id===id)}
function saveGame(){localStorage.setItem(SAVE_KEY,JSON.stringify(game));toast("Game saved!")}
function loadGame(){let s=localStorage.getItem(SAVE_KEY);if(s){game=JSON.parse(s);renderAll();toast("Save loaded!")}else toast("No save found.")}
function resetGame(){if(confirm("Reset all supermarket progress?")){localStorage.removeItem(SAVE_KEY);location.reload()}}
function toast(t){let x=document.getElementById("toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),1800)}
function log(t){game.log.unshift(t);game.log=game.log.slice(0,15)}
function setStatus(t){document.getElementById("status").textContent=t}
function renderTop(){document.getElementById("day").textContent=game.day;document.getElementById("cash").textContent=money(game.money);let h=Math.floor(game.minute/60),m=game.minute%60;document.getElementById("clock").textContent=`${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`}
function renderShelves(){
 const w=document.getElementById("world-items");w.innerHTML="";
 PRODUCTS.forEach((p,i)=>{let el=document.createElement("div");el.className="shelf";el.style.left=(22+(i%3)*23)+"%";el.style.top=(12+Math.floor(i/3)*27)+"%";
 el.innerHTML=`<div class="name">${p.icon} ${p.name}</div><div class="bars">${p.icon.repeat(Math.min(8,Math.ceil(game.stock[p.id]/2)))}</div><small>${game.stock[p.id]} in stock</small>`;w.appendChild(el)})
}
function renderCatalog(){
 document.getElementById("catalog").innerHTML=PRODUCTS.map(p=>`<div class="card"><h3>${p.icon} ${p.name}</h3><p>Wholesale: $${money(p.cost)} each<br>Store price: $${money(p.price)}<br>In stock: ${game.stock[p.id]}</p><button onclick="order('${p.id}',6)">Order 6 — $${money(p.cost*6)}</button> <button onclick="order('${p.id}',24)">Order 24 — $${money(p.cost*24)}</button></div>`).join("");
}
function order(id,qty){let p=product(id),cost=p.cost*qty;if(game.money<cost){toast("Not enough money.");return}game.money-=cost;game.expenses+=cost;game.stock[id]+=qty;log(`Ordered ${qty} ${p.name}.`);renderAll();toast("Stock delivered!")}
function renderBusiness(){
 document.getElementById("stats").innerHTML=[
 ["Cash","$"+money(game.money)],["Revenue","$"+money(game.revenue)],["Expenses","$"+money(game.expenses)],["Items sold",game.sold],["Customers",game.customers],["Profit","$"+money(game.revenue-game.expenses)]
 ].map(x=>`<div class="stat">${x[0]}<b>${x[1]}</b></div>`).join("");
 document.getElementById("log").innerHTML=game.log.map(x=>"• "+x).join("<br>");
}
const UP=[
{id:"shelves",name:"More Shelves",desc:"Increase store capacity and presentation.",base:250,max:5},
{id:"checkout",name:"Better Checkout",desc:"Customers move through checkout faster.",base:400,max:3},
{id:"store",name:"Store Expansion",desc:"Unlock a larger floor area.",base:900,max:3}
];
function renderUpgrades(){document.getElementById("upgrades-list").innerHTML=UP.map(u=>{let lvl=game.upgrade[u.id],cost=u.base*(lvl+1);return `<div class="card"><h3>🔧 ${u.name}</h3><p>${u.desc}<br>Level ${lvl}/${u.max}</p><button ${lvl>=u.max?"disabled":""} onclick="upgrade('${u.id}')">${lvl>=u.max?"MAX":"Upgrade — $"+cost}</button></div>`}).join("")}
function upgrade(id){let u=UP.find(x=>x.id===id),lvl=game.upgrade[id],cost=u.base*(lvl+1);if(lvl>=u.max)return;if(game.money<cost){toast("Not enough money.");return}game.money-=cost;game.expenses+=cost;game.upgrade[id]++;log(`${u.name} upgraded to level ${lvl+1}.`);renderAll();toast("Upgrade purchased!")}
function renderAll(){renderTop();renderShelves();renderCatalog();renderBusiness();renderUpgrades()}
function openTab(tab){activeTab=tab;document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x.dataset.tab===tab));document.querySelectorAll(".panel").forEach(x=>x.classList.toggle("active",x.id===tab))}
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>openTab(b.dataset.tab));

function serve(){
 let available=PRODUCTS.filter(p=>game.stock[p.id]>0);if(!available.length){setStatus("Customers left because the shelves are empty.");return}
 let p=available[Math.floor(Math.random()*available.length)],revenue=p.price;
 game.stock[p.id]--;game.money+=revenue;game.revenue+=revenue;game.sold++;game.customers++;
 setStatus(`Customer bought ${p.name} for $${money(revenue)}. Profit on this sale: $${money(revenue-p.cost)}.`);
 log(`Sold ${p.name} for $${money(revenue)}.`);renderAll();
}
function spawnCustomer(){
 if(customers.length>=5+game.upgrade.store*2)return;
 let c={x:18+Math.random()*65,y:25+Math.random()*45,targetX:Math.random()*70+15,targetY:Math.random()*55+15,wait:0};
 customers.push(c);renderCustomers();
}
function renderCustomers(){let box=document.getElementById("customers");box.innerHTML="";customers.forEach((c,i)=>{let e=document.createElement("div");e.className="customer";e.style.left=c.x+"%";e.style.top=c.y+"%";e.innerHTML=`🧑<span class="bubble">${c.wait>0?"Buying…":"Shopping"}</span>`;box.appendChild(e)})}
function customerTick(){
 customers.forEach(c=>{let dx=c.targetX-c.x,dy=c.targetY-c.y,d=Math.hypot(dx,dy);if(d<1){c.wait++;if(c.wait>8){serve();c.wait=0;c.targetX=18+Math.random()*65;c.targetY=25+Math.random()*45}}else{c.x+=dx/d*.45;c.y+=dy/d*.45}});
 if(Math.random()<.035)spawnCustomer();renderCustomers();
}
function nextDay(){
 if(customers.length){toast("Let the current shoppers finish.");return}
 game.day++;game.minute=480;let rent=80+game.day*10;game.money-=rent;game.expenses+=rent;log(`Day ${game.day} started. Rent/overhead: $${rent}.`);
 if(game.money<0)game.money=0;renderAll();toast("New day started.")
}
document.addEventListener("keydown",e=>{keys[e.key.toLowerCase()]=true;if(e.key.toLowerCase()==="e")serve();if(e.key==="1")setStatus("Checkout mode: press E to serve a customer.");if(e.key==="2")openTab("orders")});
document.addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);
function move(){
 let dx=0,dy=0;if(keys.w||keys.arrowup)dy-=player.speed;if(keys.s||keys.arrowdown)dy+=player.speed;if(keys.a||keys.arrowleft)dx-=player.speed;if(keys.d||keys.arrowright)dx+=player.speed;
 player.x=Math.max(3,Math.min(93,player.x+dx));player.y=Math.max(5,Math.min(88,player.y+dy));
 let el=document.getElementById("player");el.style.left=player.x+"%";el.style.top=player.y+"%";requestAnimationFrame(move)
}
setInterval(()=>{if(activeTab==="store"){game.minute++;if(game.minute>=1320)nextDay();renderTop()}},1000);
setInterval(customerTick,250);
setInterval(()=>saveGame(),15000);
renderAll();move();spawnCustomer();spawnCustomer();
window.addEventListener("beforeunload",saveGame);
